ISS Construction Manager — Android Studio Project

এটি Android APK বানানোর source project; APK ফাইল নিজে নয়।

APK বানানোর ধাপ:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio > Open চাপুন এবং এই ZIP Extract করা ISS_Construction_Manager_Android ফোল্ডারটি খুলুন।
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন। SDK Platform 35 চাইলে Android Studio-র SDK Manager থেকে ইনস্টল করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5. APK পাবেন: app/build/outputs/apk/debug/app-debug.apk
6. APK ফোনে পাঠিয়ে খুলুন। Android চাইলে “Install unknown apps” অনুমতি দিন, তারপর Install করুন।

নোট:
- অ্যাপের প্রথম Excel-ভিত্তিক ডেটা assets-এ প্যাক করা আছে।
- ডেটা এই ফোনের অ্যাপের WebView storage-এ থাকে। অ্যাপ uninstall/clear data করলে স্থানীয় পরিবর্তন হারাতে পারেন; নিয়মিত Backup নিন।
- Cloud sync / দুই ফোনে shared login এখনো নেই।
- Debug APK পরীক্ষার জন্য। Public distribution-এর আগে signed release APK তৈরি করুন।
